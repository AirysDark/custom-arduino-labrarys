# Generator Unit Tests
pip install -r tests/requirements.txt
pytest -q
