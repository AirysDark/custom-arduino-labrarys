#pragma once
#define DB_STATIC_ASSERT(cond, msg) static_assert(cond, msg)
#define DB_MIN_PARTITIONS   4
#define DB_MIN_PATHS        4
#define DB_MIN_PRINTCODES   10
#define DB_MIN_MACROS       1
