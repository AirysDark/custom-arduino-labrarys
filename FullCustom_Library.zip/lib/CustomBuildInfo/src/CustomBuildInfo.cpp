\
#include "CustomBuildInfo.h"
// Header-only. This file exists so PlatformIO consistently compiles the library.
