\
#pragma once
#include <Arduino.h>

// If not injected by the build script, fall back safely.
#ifndef CUSTOM_VERSION
  #define CUSTOM_VERSION "unknown"
#endif

namespace CustomBuildInfo {

  // Returns platformio.ini [platformio] custom_version (injected at build time)
  inline const char* version() { return CUSTOM_VERSION; }

  // Optional helper: prints nicely
  inline void printTo(Stream& s = Serial) {
    s.print("Custom Version: ");
    s.println(version());
  }

} // namespace CustomBuildInfo
