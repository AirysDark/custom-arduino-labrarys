# CustomBuildInfo (PlatformIO / Arduino Library)

This library exposes a `custom_version` value from `platformio.ini` as a compile-time macro
and provides a small Arduino-friendly API to access it.

## 1) Add custom_version to platformio.ini

```ini
[platformio]
custom_version = 1.2.3-dev
```

## 2) Enable the build hook script

Inside your environment section (example: env:esp32dev):

```ini
extra_scripts =
  pre:lib/CustomBuildInfo/scripts/custom_build_info.py
```

## 3) Use it in firmware

```cpp
#include <CustomBuildInfo.h>

void setup() {
  Serial.begin(115200);
  delay(300);
  CustomBuildInfo::printTo();
}

void loop() {}
```

Expected output:

```
Custom Version: 1.2.3-dev
```

## Notes

- If the script is not enabled, the version falls back to "unknown".
- Works with any PlatformIO platform/framework that uses the Arduino headers.

MIT Licensed.
