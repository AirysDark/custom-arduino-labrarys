# FullCustom_Library

A tiny Arduino/PlatformIO library that exposes a **compile-time** version string:

- `FullCustom_Library::version()`

> Important: firmware code cannot modify `platformio.ini`. PlatformIO settings must be provided at build time.

---

## ✅ User-friendly setup (keep custom_version, no scripts)

### 1) Put your version in the [platformio] section

```ini
[platformio]
custom_version = 1.2.3-dev
```

### 2) Map it into a compiler define with build_flags

```ini
[env:esp32dev]
build_flags =
  -DCUSTOM_VERSION=\"${platformio.custom_version}\"
```

That’s the whole bridge: PlatformIO expands `${platformio.custom_version}` and the compiler receives
`CUSTOM_VERSION="1.2.3-dev"`.

---

## Alternative setups

### Option A — Hardcode version in build flags (simplest)

```ini
build_flags =
  -DCUSTOM_VERSION=\"1.2.3-dev\"
```

### Option B — Environment variable (best for CI / users)

```ini
build_flags =
  -DCUSTOM_VERSION=\"${sysenv.BUILD_VER}\"
```

Set the env var before building:

**PowerShell**
```powershell
$env:BUILD_VER="1.2.3-dev"
pio run
```

**CMD**
```bat
set BUILD_VER=1.2.3-dev && pio run
```

**Linux/macOS**
```bash
BUILD_VER=1.2.3-dev pio run
```

---

## Use in code (inside setup/loop, not global)

```cpp
#include <Arduino.h>
#include <FullCustom_Library.h>

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println(FullCustom_Library::version());
}

void loop() {}
```

---

## Install via lib_deps (GitHub ZIP)

Use the **raw** ZIP URL (NOT the /blob/ URL):

```ini
lib_deps =
  https://github.com/AirysDark/custom-arduino-labrarys/raw/main/FullCustom_Library.zip
```

MIT Licensed.
