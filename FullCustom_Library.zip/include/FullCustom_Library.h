#pragma once
#include <Arduino.h>

/*
  FullCustom_Library — Build info (version) helper

  This library does NOT touch PlatformIO config at runtime (impossible).
  It simply exposes a compile-time define:

      CUSTOM_VERSION

  ✅ User-friendly setup (no Python scripts, no custom project options):

  Option A (simplest, always works):
    platformio.ini:
      [env:YOUR_ENV]
      build_flags =
        -DCUSTOM_VERSION=\"1.2.3-dev\"

  Option B (recommended for teams/CI):
    Use an environment variable so users don’t edit the ini:
      platformio.ini:
        [env:YOUR_ENV]
        build_flags =
          -DCUSTOM_VERSION=\"${sysenv.BUILD_VER}\"

    Then set BUILD_VER before building:
      Windows PowerShell:
        $env:BUILD_VER="1.2.3-dev"; pio run
      CMD:
        set BUILD_VER=1.2.3-dev && pio run
      Linux/macOS:
        BUILD_VER=1.2.3-dev pio run

  If CUSTOM_VERSION is not provided, it falls back to "unknown".
*/

#ifndef CUSTOM_VERSION
  #define CUSTOM_VERSION "unknown"
#endif

namespace FullCustom_Library {

  // Returns the compile-time firmware version string.
  inline constexpr const char* version() {
    return CUSTOM_VERSION;
  }

  // Returns true if a real version was injected.
  inline bool hasVersion() {
    return String(CUSTOM_VERSION) != String("unknown");
  }

} // namespace FullCustom_Library
