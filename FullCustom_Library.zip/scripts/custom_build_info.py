\
Import("env")

# Read from [platformio] section:
# [platformio]
# custom_version = 1.2.3
custom_version = env.GetProjectOption("custom_version", "unknown")

# Inject compile-time define as a C string literal
env.Append(
    CPPDEFINES=[
        ("CUSTOM_VERSION", f'\\"{custom_version}\\"')
    ]
)

print("[FullCustom_Library] Injected CUSTOM_VERSION =", custom_version)
